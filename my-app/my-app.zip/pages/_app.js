import "../styles/globals.css"

export default function Myapp({ Component, pageProps }) {
  return (
    <>

      <Component {...pageProps} />
    </>
  )
}
